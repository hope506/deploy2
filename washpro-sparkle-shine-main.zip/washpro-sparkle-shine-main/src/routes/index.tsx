import { createFileRoute } from "@tanstack/react-router";
import { Droplets, Sparkles, Shield, Car, Check, Star, ArrowRight, Phone } from "lucide-react";
import heroCar from "@/assets/hero-car.jpg";
import serviceExterior from "@/assets/service-exterior.jpg";
import serviceInterior from "@/assets/service-interior.jpg";
import serviceCeramic from "@/assets/service-ceramic.jpg";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* NAV */}
      <header className="fixed top-0 inset-x-0 z-50 glass">
        <nav className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
          <a href="#top" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-md bg-electric flex items-center justify-center shadow-glow">
              <Droplets className="w-4 h-4 text-primary-foreground" strokeWidth={2.5} />
            </div>
            <span className="font-display text-lg tracking-widest">WAXWORKSMOBILE</span>
          </a>
          <div className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
            <a href="#services" className="hover:text-electric transition-colors">Services</a>
            <a href="#process" className="hover:text-electric transition-colors">Process</a>
            <a href="#pricing" className="hover:text-electric transition-colors">Pricing</a>
            <a href="#contact" className="hover:text-electric transition-colors">Contact</a>
          </div>
          <a href="#contact" className="inline-flex items-center gap-2 bg-electric text-primary-foreground px-5 py-2.5 rounded-md text-sm font-semibold hover:opacity-90 transition shadow-glow">
            Book Now <ArrowRight className="w-4 h-4" />
          </a>
        </nav>
      </header>

      {/* HERO */}
      <section id="top" className="relative min-h-screen flex items-center pt-20 bg-hero">
        <div className="absolute inset-0 opacity-40">
          <img src={heroCar} alt="Freshly detailed luxury car" className="w-full h-full object-cover" width={1920} height={1280} />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-transparent to-background/40" />
        </div>

        <div className="relative max-w-7xl mx-auto px-6 py-24 grid lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-8">
            <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full text-xs uppercase tracking-widest text-electric">
              <Sparkles className="w-3.5 h-3.5" /> Mobile Detailing — Pretoria
            </div>
            <h1 className="font-display text-5xl md:text-7xl lg:text-8xl leading-[0.9] tracking-tight">
              MIRROR<br />
              <span className="text-gradient">FINISH.</span><br />
              OBSESSION.
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-xl leading-relaxed">
              WaxWorksMobile brings the studio to your driveway across Pretoria — hand-polished, wax-sealed, and finished to a mirror gloss most drivers only see in showrooms.
            </p>
            <div className="flex flex-wrap gap-4">
              <a href="#pricing" className="inline-flex items-center gap-2 bg-electric text-primary-foreground px-8 py-4 rounded-md font-semibold hover:opacity-90 transition shadow-glow animate-pulse-glow">
                Reserve Your Slot <ArrowRight className="w-4 h-4" />
              </a>
              <a href="#services" className="inline-flex items-center gap-2 glass px-8 py-4 rounded-md font-semibold hover:border-electric transition">
                See The Work
              </a>
            </div>
            <div className="flex items-center gap-6 pt-4">
              <div className="flex -space-x-2">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="w-8 h-8 rounded-full bg-electric/20 border-2 border-background" />
                ))}
              </div>
              <div className="flex items-center gap-1.5 text-sm">
                <div className="flex text-electric">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-current" />)}
                </div>
                <span className="text-muted-foreground ml-1">1,200+ obsessed customers</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 hidden lg:block">
            <div className="glass rounded-2xl p-8 space-y-6 shadow-elegant">
              <div className="text-xs uppercase tracking-widest text-electric">This Week</div>
              <div className="font-display text-4xl">3 Slots Left</div>
              <div className="space-y-4">
                {[
                  { day: "Thu", time: "10:00 AM", type: "Full Detail" },
                  { day: "Fri", time: "02:00 PM", type: "Ceramic Coat" },
                  { day: "Sat", time: "09:00 AM", type: "Express Wash" },
                ].map((s) => (
                  <div key={s.day} className="flex items-center justify-between border-b border-border/50 pb-3">
                    <div>
                      <div className="text-sm font-semibold">{s.day} — {s.time}</div>
                      <div className="text-xs text-muted-foreground">{s.type}</div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-electric" />
                  </div>
                ))}
              </div>
              <a href="#contact" className="block text-center bg-electric text-primary-foreground py-3 rounded-md font-semibold hover:opacity-90 transition">
                Claim a Slot
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* MARQUEE STATS */}
      <section className="border-y border-border bg-card/30">
        <div className="max-w-7xl mx-auto px-6 py-12 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { n: "12+", l: "Years Perfecting" },
            { n: "8,400", l: "Cars Restored" },
            { n: "4.9★", l: "Google Rating" },
            { n: "100%", l: "Guarantee" },
          ].map((s) => (
            <div key={s.l} className="text-center">
              <div className="font-display text-4xl md:text-5xl text-electric">{s.n}</div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground mt-2">{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="max-w-7xl mx-auto px-6 py-32">
        <div className="max-w-2xl mb-16">
          <div className="text-xs uppercase tracking-widest text-electric mb-4">01 — Services</div>
          <h2 className="font-display text-4xl md:text-6xl leading-tight">
            Every square inch,<br /><span className="text-gradient">obsessed over.</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            { img: serviceExterior, title: "Exterior Detail", desc: "Two-bucket hand wash, clay-bar decontamination, machine polish. Your paint reborn.", price: "From R750" },
            { img: serviceInterior, title: "Interior Restoration", desc: "Steam extraction, leather conditioning, UV protection. A cabin that feels new.", price: "From R750" },
            { img: serviceCeramic, title: "Ceramic Coating", desc: "9H nano-ceramic sealant. Up to 5 years of hydrophobic, scratch-resistant gloss.", price: "From R750" },
          ].map((s) => (
            <div key={s.title} className="group glass rounded-2xl overflow-hidden hover:border-electric transition-all hover:shadow-glow">
              <div className="aspect-[4/3] overflow-hidden">
                <img src={s.img} alt={s.title} loading="lazy" width={1024} height={1024} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
              </div>
              <div className="p-6 space-y-3">
                <h3 className="font-display text-2xl">{s.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
                <div className="flex items-center justify-between pt-3 border-t border-border/50">
                  <span className="text-electric font-semibold">{s.price}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PROCESS */}
      <section id="process" className="bg-card/30 border-y border-border">
        <div className="max-w-7xl mx-auto px-6 py-32">
          <div className="text-xs uppercase tracking-widest text-electric mb-4">02 — Ritual</div>
          <h2 className="font-display text-4xl md:text-6xl mb-16 max-w-3xl leading-tight">
            The four-step<br /><span className="text-gradient">obsession protocol.</span>
          </h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: Droplets, step: "01", title: "Decontaminate", desc: "Foam bath and clay-bar strip every embedded contaminant." },
              { icon: Sparkles, step: "02", title: "Correct", desc: "Multi-stage machine polish erases swirls and oxidation." },
              { icon: Shield, step: "03", title: "Protect", desc: "Ceramic or sealant bonds an invisible armor to the paint." },
              { icon: Car, step: "04", title: "Deliver", desc: "White-glove hand-off with maintenance kit and instructions." },
            ].map((p) => (
              <div key={p.step} className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-electric/10 border border-electric/30 flex items-center justify-center">
                    <p.icon className="w-5 h-5 text-electric" />
                  </div>
                  <div className="font-display text-3xl text-muted-foreground/40">{p.step}</div>
                </div>
                <h3 className="font-display text-xl">{p.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="max-w-7xl mx-auto px-6 py-32">
        <div className="text-center mb-16">
          <div className="text-xs uppercase tracking-widest text-electric mb-4">03 — Packages</div>
          <h2 className="font-display text-4xl md:text-6xl">Pick your <span className="text-gradient">obsession level.</span></h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { name: "Signature", price: "750", tag: "Weekly Refresh", features: ["Hand wash & dry", "Wheel & tire dress", "Interior vacuum", "Window clarity", "Tire shine"] },
            { name: "Elite", price: "750", tag: "Most Booked", featured: true, features: ["Everything in Signature", "Clay-bar decon", "Single-stage polish", "Full interior steam", "Leather conditioning", "6-month sealant"] },
            { name: "Concours", price: "750", tag: "Showroom Grade", features: ["Everything in Elite", "Multi-stage correction", "9H ceramic coating", "Engine bay detail", "PPF-ready prep", "5-year warranty"] },
          ].map((p) => (
            <div key={p.name} className={`relative rounded-2xl p-8 ${p.featured ? "bg-electric text-primary-foreground shadow-glow scale-105" : "glass"}`}>
              {p.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-background text-electric text-xs uppercase tracking-widest px-4 py-1 rounded-full border border-electric">
                  {p.tag}
                </div>
              )}
              {!p.featured && <div className="text-xs uppercase tracking-widest text-muted-foreground mb-3">{p.tag}</div>}
              <div className="font-display text-3xl mb-2">{p.name}</div>
              <div className="flex items-baseline gap-1 mb-8">
                <span className={`text-5xl font-display ${p.featured ? "" : "text-electric"}`}>R{p.price}</span>
                <span className={p.featured ? "text-primary-foreground/70" : "text-muted-foreground"}>/ visit</span>
              </div>
              <ul className="space-y-3 mb-8">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${p.featured ? "" : "text-electric"}`} />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <a href="#contact" className={`block text-center py-3 rounded-md font-semibold transition ${p.featured ? "bg-background text-electric hover:opacity-90" : "bg-electric text-primary-foreground hover:opacity-90"}`}>
                Book {p.name}
              </a>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIAL */}
      <section className="bg-card/30 border-y border-border">
        <div className="max-w-4xl mx-auto px-6 py-24 text-center space-y-8">
          <div className="flex justify-center text-electric">
            {[...Array(5)].map((_, i) => <Star key={i} className="w-6 h-6 fill-current" />)}
          </div>
          <blockquote className="font-display text-2xl md:text-4xl leading-tight">
            "I've owned this car five years. After WaxWorksMobile, it looked better than the day I drove it off the lot. <span className="text-gradient">Genuinely unreal.</span>"
          </blockquote>
          <div className="text-sm text-muted-foreground uppercase tracking-widest">
            Marcus D. — Porsche 911 Owner
          </div>
        </div>
      </section>

      {/* CTA / CONTACT */}
      <section id="contact" className="max-w-7xl mx-auto px-6 py-32">
        <div className="glass rounded-3xl p-12 md:p-20 text-center relative overflow-hidden shadow-elegant">
          <div className="absolute inset-0 bg-electric/5" />
          <div className="relative space-y-8">
            <h2 className="font-display text-4xl md:text-7xl leading-tight">
              Your car deserves<br /><span className="text-gradient">the obsession.</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">
              Mobile service across Pretoria. Slots fill fast — reserve yours and drive out turning heads.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <a href="tel:+27742753927" className="inline-flex items-center gap-2 bg-electric text-primary-foreground px-8 py-4 rounded-md font-semibold hover:opacity-90 transition shadow-glow">
                <Phone className="w-4 h-4" /> 074 275 3927
              </a>
              <a href="mailto:WaxWorksMobile@gmail.com" className="inline-flex items-center gap-2 glass px-8 py-4 rounded-md font-semibold hover:border-electric transition">
                WaxWorksMobile@gmail.com
              </a>
            </div>
            <div className="text-xs uppercase tracking-widest text-muted-foreground pt-2">Serving Pretoria & Surrounds</div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-border">
        <div className="max-w-7xl mx-auto px-6 py-12 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-electric flex items-center justify-center">
              <Droplets className="w-3 h-3 text-primary-foreground" strokeWidth={2.5} />
            </div>
            <span className="font-display text-sm tracking-widest">WAXWORKSMOBILE</span>
          </div>
          <div className="text-xs text-muted-foreground">© {new Date().getFullYear()} WaxWorksMobile Detailing — Pretoria.</div>
        </div>
      </footer>
    </div>
  );
}
